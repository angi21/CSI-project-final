/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.*;

public class CallClassMatch {
    CallClassMatch()
    {
    }
    
    public void show()
    {
        try
    {
            
    Runtime rt = Runtime.getRuntime() ;
 Process p = rt.exec("CVKMeans") ;
 InputStream in = p.getInputStream() ;
 OutputStream out = p.getOutputStream ();
    }
    catch (Exception ex){}
    }   
        
    }
    
            

