import java.io.*;

public class CallClassSegment {
    CallClassSegment()
    {
        try
    {
            
    Runtime rt = Runtime.getRuntime() ;
 Process p = rt.exec("ED") ;
 InputStream in = p.getInputStream() ;
 OutputStream out = p.getOutputStream ();
    }
    catch (Exception ex){}
    }
            
}