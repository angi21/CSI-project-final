/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

public class MyTest {
    public void Show()
    {
    CallClassFeat f1=new CallClassFeat();
    
    }
    public void ShowSeg()
    {
    CallClassSegment f1=new CallClassSegment();
    
    }
    
    public void ShowFeat()
    {
    CallClassFeat f1=new CallClassFeat();
    
    }
    
    public void ShowMatch()
    {
    CallClassMatch f1=new CallClassMatch();
    
    }
    
    
}
