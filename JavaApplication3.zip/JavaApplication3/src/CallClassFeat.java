import java.io.*;

public class CallClassFeat{
    CallClassFeat()
    {
        try
    {
            
    Runtime rt = Runtime.getRuntime() ;
 Process p = rt.exec("CVKMeans") ;
 InputStream in = p.getInputStream() ;
 OutputStream out = p.getOutputStream ();
    }
    catch (Exception ex){}
    }
            
}